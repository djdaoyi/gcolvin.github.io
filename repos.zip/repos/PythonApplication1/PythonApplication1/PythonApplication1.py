import sys
import tkinter as tk
#from HelperFunctions import *

global coordinates
global start
start = 0
coordinates = []
global global_count 
global_count = 0
global Width
Width = 500
global Height 
Height = 500



def _create_circle(self, x, y, r, **kwargs):
    return self.create_oval(x-r, y-r, x+r, y+r, **kwargs)
tk.Canvas.create_circle = _create_circle

def write_slogan():
    print("progress")

def counter():
    global global_count 
    global_count += 1
    print(global_count)

def callback(event):
    global coordinates
    coordinates.append(event.x)
    coordinates.append(event.y)

    print ("clicked at", event.x, event.y)
    canvas.create_circle(event.x, event.y, 25, fill="blue", outline="#DDD", width=2)
    canvas.create_text(event.x, event.y, anchor=tk.CENTER, font="Purisa", text="Bubble")
    trace_edge()

def trace_edge():
    global coordinates
    global start
    if len(coordinates) > 2:
        for i in range(start, (int)(len(coordinates)) - 2 , 2):
            canvas.create_line( coordinates[i], coordinates[i+1], coordinates[i+2], 
                                coordinates[i+3], fill="green")

        start = start + 2

def path():
    global start
    global coordinates


root = tk.Tk()
root.geometry("500x500+50+50")

frame = tk.Frame(root)
frame.pack()

canvas = tk.Canvas(root, width=300, height=300, borderwidth=0, highlightthickness=0, bg="white")
canvas.bind("<Button-1>", callback)
canvas.pack()

button = tk.Button(frame, text = "QUIT", fg = "red" , command = "quit")

button.pack(side = tk.LEFT)

slogan = tk.Button(frame, text = "Hello", command = write_slogan)
slogan.pack(side = tk.LEFT)

forFun = tk.Button(frame, text = "count", command = counter)
forFun.pack(side = tk.LEFT)


algorithm = tk.Button(frame, text = "Djikstras")
algorithm.pack(side = tk.BOTTOM)

# append center points to a vector and draw lines connecting the center points
# usilize hast table? / potentially a dictionary in python
root.mainloop()





