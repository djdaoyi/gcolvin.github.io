import sys
import tkinter as tk


def _create_circle(self, x, y, r, **kwargs):
    return self.create_oval(x-r, y-r, x+r, y+r, **kwargs)


def write_slogan():
    print("progress")

def counter():
    global global_count 
    global_count += 1
    print(global_count)

def callback(event):
    print ("clicked at", event.x, event.y)
    #tk.Canvas.create_circle = _create_circle()


