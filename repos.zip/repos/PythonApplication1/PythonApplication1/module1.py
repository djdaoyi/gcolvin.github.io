import sys
import tkinter as tk

def write_slogan():
    print("progress")

def counter():
    global global_count 
    global_count += 1
    print(global_count)
def callback(event):
    print "clicked at", event.x, event.y

    frame = Frame(root, width=100, height=100)
    frame.bind("<Button-1>", callback)
    frame.pack()